<?
$sSectionName="тест";
?>